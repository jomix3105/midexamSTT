package test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCourseperDpt {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
