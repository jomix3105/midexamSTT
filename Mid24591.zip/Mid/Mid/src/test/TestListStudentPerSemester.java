package test;

import static org.junit.Assert.*;

import java.util.Collections;
import java.util.List;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.*;

import dao.CourseDao;
import dao.StudentRegistrationDao;
import model.Semester;
import model.Student;
import model.AcademicUnit;
import model.Course;


public class TestListStudentPerSemester {
StudentRegistrationDao studentRegistrationDao = new StudentRegistrationDao();
CourseDao coursedao = new CourseDao();
	   @Before
	   public void setUp() {
	      this.studentRegistrationDao = new StudentRegistrationDao();
	      this.coursedao = new CourseDao();
	   }



	    @Test
	    public void testGetAllStudentsBySemester() {
	        Semester semester = new Semester();
	        semester.setSemId("se");

	        List<Student> students = this.studentRegistrationDao.getAllStudentsBySemester(semester);

	        assertNotNull(students);
	        assertEquals(1, students.size()); 
	        assertEquals("fadi", students.get(0).getNames()); // Assert the name of the first student
	    }
	    
	    @Test
	    
	    public void testGetAllStudentsByDepartmentSemester() {
	        Semester semester = new Semester();
	        semester.setSemId("se3");
	        
	        AcademicUnit unit = new AcademicUnit();
	        unit.setUnitCode("COMPSCI");
	        
	        List<Student> students = this.studentRegistrationDao.getAllStudentsByDepartmentAndSemester(unit, semester);
	        assertNotNull(students);
	        assertEquals(1, students.size()); 
	        assertEquals("daniells", students.get(0).getNames());
	    }
	    
	    @Test
	    
	    public void testGetAllStudentsByCourseSemester() {
	        Semester semester = new Semester();
	        semester.setSemId("se");
	        
	        Course course = new Course();
	        course.setCourseCode("seng5");
	        
	        List<Student> students = this.studentRegistrationDao.getStudentsByCourseAndSemester(course, semester);
	        assertNotNull(students);
	        assertEquals(1, students.size()); 
	        assertEquals("fadi", students.get(0).getNames());
	    }
	    @Test
	    public void testGetAllCourseByStudent() {
	        Student student = new Student();
	        student.setRegNo("24650");
	
	        
	        List<Course> courses = this.coursedao.getCoursesByStudent(student);
	        assertNotNull(courses);
	        assertEquals(1, courses.size()); 
	        assertEquals("software", courses.get(0).getCourseName());
	    }   
	    
	    @Test
	    public void testGetAllCourseByDepartmentSemester() {
	        Semester semester = new Semester();
	        semester.setSemId("se3");;
	        
	        AcademicUnit unit = new AcademicUnit();
	        unit.setUnitCode("COMPSCI");
	        
	        List<Course> courses = this.coursedao.getCoursesByDepartmentAndSemester(unit, semester);
	        assertNotNull(courses);
	        assertEquals(1, courses.size()); 
	        assertEquals("software", courses.get(0).getCourseName());
	    }
	    
	    }
	    
