/*
 * package repository;
 * 
 * 
 * import org.hibernate.*; import org.hibernate.cfg.Configuration;
 * 
 * public class HibernateUtility { private static final SessionFactory session =
 * buildSessionFactory();
 * 
 * private static SessionFactory buildSessionFactory() throws HibernateException
 * { try { // Create the SessionFactory from hibernate.cfg.xml return new
 * Configuration().configure().buildSessionFactory(); } catch (Throwable ex) {
 * // Make sure you log the exception, as it might be swallowed
 * System.err.println("Initial SessionFactory creation failed." + ex); throw new
 * ExceptionInInitializerError(ex); } }
 * 
 * public static SessionFactory getSession() { return session; } }
 */

package repository;

import org.hibernate.SessionFactory;
import model.*;
import java.util.Properties;


import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtility {
private static SessionFactory sessionFactory;
	
	public static SessionFactory getSession() {
		if(sessionFactory == null) {
			try {
				Configuration configuration = new Configuration();

				// Hibernate settings equivalent to hibernate.cfg.xml's properties
				Properties settings = new Properties();
				settings.put(Environment.DRIVER, "org.postgresql.Driver");
				settings.put(Environment.URL, "jdbc:postgresql://localhost:5432/new_db");
				settings.put(Environment.USER, "postgres");
				settings.put(Environment.PASS, "joseph123");
				settings.put(Environment.DIALECT, "org.hibernate.dialect.PostgreSQLDialect");

				settings.put(Environment.SHOW_SQL, "false");

				settings.put(Environment.CURRENT_SESSION_CONTEXT_CLASS, "thread");

				settings.put(Environment.HBM2DDL_AUTO, "update");

				
				configuration.setProperties(settings);
				configuration.addAnnotatedClass(Student.class);
				configuration.addAnnotatedClass(StudentRegistration.class);
				configuration.addAnnotatedClass(AcademicUnit.class);
				configuration.addAnnotatedClass(Course.class);
				configuration.addAnnotatedClass(StudentCourse.class);
				configuration.addAnnotatedClass(Semester.class);
				configuration.addAnnotatedClass(Teacher.class);
				
				
				ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
						.applySettings(configuration.getProperties()).build();
				System.out.println("Hibernate Java Config serviceRegistry created");
				sessionFactory = configuration.buildSessionFactory(serviceRegistry);
				return sessionFactory;

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return sessionFactory;
	}
	

}